/*
 * @Author: your name
 * @Date: 2020-12-10 14:19:33
 * @LastEditTime: 2020-12-15 14:51:42
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \myGulpc:\Users\wing\Desktop\gulps\src\router\hello.js
 */
export const div = () => {
    const div = document.createElement('div')
    div.contentEditable = true;
    return div
    console.log('hahahahaha')
}
export const a = () => "100";
export const b = () => '90';