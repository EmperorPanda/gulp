module.exports = {
    router: {
        // base: '/test',
        // extendRoutes (routes, resolve) {
        //     routes.push({
        //         path: '/123',
        //         name: 'hello',
        //         component: resolve(__dirname, 'pages/index.vue')
        //     })
        // }
    }
}