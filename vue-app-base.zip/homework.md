# Webpack 的构建流程主要有哪些环节？如果可以请尽可能详尽的描述 Webpack 打包的整个过程

1. 配置entry和output，入口文件和输出文件路径
2. module配置相应的解析规则，引入loader对模块进行解析和转换处理
3. plugin对项目的构建进行拓展，提供更多的拓展功能，可对模块进行优化处理
4. 服务等

## webpack打包过程

1. 使用webpack的时候，通过entry配置的入口文件，来解析entry入口文件中所依赖的所有模块，之后按照module.rules里的配置也就是loader进行相应的解析和转换，解析完成后就会以entry进行分组生成一个chunk。最后webpack会将生成的chunk打包输出到配置的output下，中间会把定义的plugin插件加入到相应的解析和打包中来，对打包任务进行优化和拓展等。

## Loader 和 Plugin 有哪些不同？请描述一下开发 Loader 和 Plugin 的思路

1. loader主要为webpack提供编译，转换处理，由于webpack处理的是js文件，所以需要loader来对不同的文件进行解析和转换，举个栗子：当我们需要解析less/css文件的时候就需要less-loader，css-loader，style-loader来对这些文件进行转换处理。所以loader更像是gulp的pipe一样，通过一个管道对文件进行加工处理，转换编译后生成webpack可以解析的文件
2. plugin为webpack提供了更多的拓展功能，为webpack提供了更多的可能，不仅仅是编译和转换，还能对webpack进行优化处理，比如js、css的压缩，打包优化，分包等loader无法提供的功能

## 开发 Loader 的思路

1. 通过module.exports导出一个函数
2. 函数的一个参数source(即要处理的资源文件，通过relus匹配过来的)
3. 在函数中处理资源(loader里配置响应的loader后，也可能借助于其他依赖例如处理markdown文件时使用marked)
4. 通过return返回最终处理后的结果(这里返回的结果需为字符串形式)

## 开发 Plugin 的思路

1. 通过钩子机制实现，在webpack每个生命周期有对应的钩子
2. 插件必须是一个函数或包含apply方法的对象
3. 在方法体内通过webpack提供的API获取资源做响应处理
4. 将处理完的资源通过webpack提供的方法返回该资源
