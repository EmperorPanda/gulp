<template>
    <div>
        <nav class="navbar navbar-light">
        <div class="container">
          <nuxt-link class="navbar-brand" to="index.html">conduit</nuxt-link>
          <ul class="nav navbar-nav pull-xs-right">
            <li class="nav-item">
              <nuxt-link exact class="nav-link" to="/">Home</nuxt-link>
            </li>
            <li class="nav-item">
              <nuxt-link class="nav-link" to="/editor">
                <i class="ion-compose"></i>&nbsp;New Post
              </nuxt-link>
            </li>
            <li class="nav-item">
              <nuxt-link class="nav-link" to="/settings">
                <i class="ion-gear-nuxt-link"></i>&nbsp;Settings
              </nuxt-link>
            </li>
            <li class="nav-item">
              <nuxt-link class="nav-link" to="/register">Sign up</nuxt-link>
            </li>
          </ul>
        </div>
      </nav>
      <nuxt-child />
      <footer>
        <div class="container">
          <nuxt-link to="/" class="logo-font">conduit</nuxt-link>
          <span class="attribution">
            An interactive learning project from <nuxt-link to="https://thinkster.io">Thinkster</nuxt-link>. Code &amp; design licensed under MIT.
          </span>
        </div>
      </footer>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>