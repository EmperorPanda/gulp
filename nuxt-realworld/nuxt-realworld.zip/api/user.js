import axios from '@/utils/request'

export const login = (data) => {
  return axios({
    method: 'POST',
    url: '/api/users/login',
    data
  })
}
export const register = (data) => {
  return axios({
    method: 'POST',
    url: '/api/users',
    data
  })
}